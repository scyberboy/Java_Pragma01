/**
 * @author Stoycho Petrov
 *
 */

public class Demo01 {
	// Comment ?
	/*
	 * Multiple line comment...
	 */

	public static void main(String[] args) {

		int i = 0;
		
		System.out.println("ala bala nica :)");
		System.out.println("second string on a new line...");
		
		System.out.printf("Local var i = %d\n", i);
		
		System.out.println(i);

		
		
	}

}
